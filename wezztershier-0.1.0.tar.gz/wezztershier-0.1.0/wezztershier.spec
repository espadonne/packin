Name:           wezztershier
Version:        0.1.0
Release:        1%{?dist}
Summary:        Beautiful GUI generator for WezTerm configuration files

License:        MIT
URL:            https://github.com/tenseleyFlow/wezzteRust
Source0:        %{name}-%{version}.tar.gz

BuildRequires:  rust >= 1.70
BuildRequires:  cargo
BuildRequires:  gcc
BuildRequires:  pkgconfig
BuildRequires:  openssl-devel
BuildRequires:  nodejs >= 18
BuildRequires:  npm

# GUI dependencies (for Tauri build)
BuildRequires:  gtk3-devel
BuildRequires:  webkit2gtk3-devel
BuildRequires:  libappindicator3-devel
BuildRequires:  librsvg2-devel

Requires:       wezterm
Suggests:       lua

%description
Wezztershier is a high-performance GUI application built in Rust that generates
beautiful configuration interfaces for WezTerm using decorator annotations
in your Lua configuration files.

Features:
- Interactive widgets: sliders, color pickers, theme selectors
- Advanced color support: Hex, RGB, HSL with alpha channels  
- Built-in theme library: Dracula, Gruvbox, Solarized, Tokyo Night, Catppuccin
- Intelligent layout with automatic widget grouping
- CLI tools for parsing, validation, and debugging
- Real-time configuration preview with live updates

%package gui
Summary:        GUI application for Wezztershier
Requires:       %{name} = %{version}-%{release}
Requires:       gtk3
Requires:       webkit2gtk3

%description gui
Tauri-based GUI application for Wezztershier providing a beautiful visual interface
for configuring WezTerm with live preview and interactive widgets.

%prep
%autosetup

%build
export PATH=$PATH:/home/espadon/.local/bin
# Build CLI
cargo build --release -p wezztershier-cli

# Build GUI (if Node.js is available)
if command -v npm >/dev/null 2>&1; then
    npm install
    npm run tauri build
fi

%install
# Install CLI binary
install -Dm755 target/release/wezztershier %{buildroot}%{_bindir}/wezztershier

# Install GUI application (if built)
if [ -f src-tauri/target/release/wezztershier-gui ]; then
    install -Dm755 src-tauri/target/release/wezztershier-gui %{buildroot}%{_bindir}/wezztershier-gui
fi

# Install configuration templates
install -Dm644 templates/basic.lua %{buildroot}%{_datadir}/wezztershier/templates/basic.lua
install -Dm644 templates/advanced.lua %{buildroot}%{_datadir}/wezztershier/templates/advanced.lua

# Install example configurations
install -Dm644 examples/test-config.lua %{buildroot}%{_docdir}/wezztershier/examples/test-config.lua

%check
# Run core library tests
cargo test -p wezztershier-core
# Run CLI tests  
cargo test -p wezztershier-cli

%files
%license LICENSE
%doc docs/README.md
%{_bindir}/wezztershier
%{_datadir}/wezztershier/
%{_docdir}/wezztershier/

%files gui
%{_bindir}/wezztershier-gui

%changelog
* Sun Jan 15 2024 espadonne (mfw) <espadonne@outlook.com> - 0.1.0-1
- Initial RPM package
- CLI tools for parsing, validation, and debugging
- Core widget library: sliders, selects, color pickers, theme selectors
- Advanced color support: Hex, RGB, HSL with alpha channels
- Built-in theme library with 5 popular themes
- Intelligent auto-layout system with widget grouping
- Performance benchmarks and comprehensive testing
- Tauri-based GUI application with live preview