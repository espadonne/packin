<script>
  import { createEventDispatcher } from 'svelte';
  import SliderWidget from './widgets/SliderWidget.svelte';
  import SelectWidget from './widgets/SelectWidget.svelte';
  import ColorPickerWidget from './widgets/ColorPickerWidget.svelte';
  import ThemeSelectorWidget from './widgets/ThemeSelectorWidget.svelte';
  
  export let widgets = {};
  
  const dispatch = createEventDispatcher();
  
  function handleWidgetChange(widgetId, value) {
    dispatch('widgetUpdate', { widgetId, value });
  }
  
  function getWidgetComponent(widget) {
    const renderData = Object.keys(widget).find(key => 
      ['slider', 'select', 'color_picker', 'theme_selector'].includes(key)
    );
    
    switch (renderData) {
      case 'slider':
        return SliderWidget;
      case 'select':
        return SelectWidget;
      case 'color_picker':
        return ColorPickerWidget;
      case 'theme_selector':
        return ThemeSelectorWidget;
      default:
        return null;
    }
  }
</script>

<div class="widget-panel">
  <div class="panel-header">
    <h2>⚙️ Configuration Widgets</h2>
    <p>Adjust settings using the controls below</p>
  </div>
  
  <div class="widgets-container">
    {#each Object.entries(widgets) as [widgetId, widget]}
      <div class="widget-wrapper">
        <div class="widget-header">
          <label class="widget-label">{widget.label}</label>
          <div class="widget-key">{widget.config_key}</div>
        </div>
        
        {#if getWidgetComponent(widget)}
          <svelte:component 
            this={getWidgetComponent(widget)}
            {widget}
            {widgetId}
            on:change={(e) => handleWidgetChange(widgetId, e.detail)}
          />
        {:else}
          <div class="unsupported-widget">
            <span>Unsupported widget type</span>
            <small>Current value: {JSON.stringify(widget.current_value)}</small>
          </div>
        {/if}
        
        {#if widget.has_changed}
          <div class="changed-indicator">
            <span>●</span> Modified
          </div>
        {/if}
      </div>
    {/each}
    
    {#if Object.keys(widgets).length === 0}
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        <h3>No widgets found</h3>
        <p>Load a configuration file to see available settings</p>
      </div>
    {/if}
  </div>
</div>

<style>
  .widget-panel {
    padding: 1.5rem;
    height: 100%;
    overflow-y: auto;
  }
  
  .panel-header {
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #e0e0e0;
  }
  
  .panel-header h2 {
    color: #333;
    font-size: 1.25rem;
    margin-bottom: 0.5rem;
  }
  
  .panel-header p {
    color: #666;
    margin: 0;
    font-size: 0.9rem;
  }
  
  .widgets-container {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
  }
  
  .widget-wrapper {
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 1.25rem;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    transition: box-shadow 0.2s ease;
  }
  
  .widget-wrapper:hover {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
  
  .widget-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
    gap: 1rem;
  }
  
  .widget-label {
    font-weight: 600;
    color: #333;
    font-size: 0.95rem;
    flex: 1;
  }
  
  .widget-key {
    font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
    font-size: 0.8rem;
    color: #666;
    background: #f8f8f8;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    white-space: nowrap;
  }
  
  .changed-indicator {
    margin-top: 0.75rem;
    color: #22c55e;
    font-size: 0.8rem;
    display: flex;
    align-items: center;
    gap: 0.25rem;
  }
  
  .changed-indicator span {
    font-size: 0.6rem;
  }
  
  .unsupported-widget {
    padding: 1rem;
    background: #f8f8f8;
    border: 1px dashed #ccc;
    border-radius: 4px;
    text-align: center;
    color: #666;
  }
  
  .unsupported-widget small {
    display: block;
    margin-top: 0.5rem;
    font-family: monospace;
  }
  
  .empty-state {
    text-align: center;
    padding: 3rem 2rem;
    color: #666;
  }
  
  .empty-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
  }
  
  .empty-state h3 {
    color: #333;
    margin-bottom: 0.5rem;
  }
  
  .empty-state p {
    margin: 0;
  }
</style>