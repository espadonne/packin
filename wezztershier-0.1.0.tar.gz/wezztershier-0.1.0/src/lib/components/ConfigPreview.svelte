<script>
  export let configPreview = '';
  
  let copySuccess = false;
  
  async function copyToClipboard() {
    try {
      await navigator.clipboard.writeText(configPreview);
      copySuccess = true;
      setTimeout(() => copySuccess = false, 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  }
</script>

<div class="config-preview">
  <div class="preview-header">
    <h2>📄 Configuration Preview</h2>
    <p>Live preview of your WezTerm configuration</p>
    
    <div class="header-actions">
      <button 
        class="copy-button" 
        class:success={copySuccess}
        on:click={copyToClipboard}
        disabled={!configPreview.trim()}
      >
        {#if copySuccess}
          ✓ Copied!
        {:else}
          📋 Copy
        {/if}
      </button>
    </div>
  </div>
  
  <div class="preview-content">
    {#if configPreview.trim()}
      <pre><code>{configPreview}</code></pre>
    {:else}
      <div class="empty-preview">
        <div class="empty-icon">⚡</div>
        <h3>Configuration will appear here</h3>
        <p>Adjust widgets on the left to see your live configuration updates</p>
      </div>
    {/if}
  </div>
</div>

<style>
  .config-preview {
    padding: 1.5rem;
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  
  .preview-header {
    flex-shrink: 0;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #e0e0e0;
    position: relative;
  }
  
  .preview-header h2 {
    color: #333;
    font-size: 1.25rem;
    margin-bottom: 0.5rem;
  }
  
  .preview-header p {
    color: #666;
    margin: 0;
    font-size: 0.9rem;
  }
  
  .header-actions {
    position: absolute;
    right: 0;
    top: 0;
  }
  
  .copy-button {
    background: #667eea;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 6px;
    font-size: 0.85rem;
    transition: all 0.2s ease;
  }
  
  .copy-button:hover:not(:disabled) {
    background: #5a67d8;
    transform: translateY(-1px);
  }
  
  .copy-button:disabled {
    background: #ccc;
    cursor: not-allowed;
    transform: none;
  }
  
  .copy-button.success {
    background: #22c55e;
  }
  
  .preview-content {
    flex: 1;
    overflow-y: auto;
    background: #fafafa;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    position: relative;
  }
  
  pre {
    margin: 0;
    padding: 1.5rem;
    font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
    font-size: 0.9rem;
    line-height: 1.4;
    white-space: pre-wrap;
    word-wrap: break-word;
    color: #333;
  }
  
  code {
    font-family: inherit;
  }
  
  .empty-preview {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    color: #666;
    max-width: 300px;
  }
  
  .empty-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.7;
  }
  
  .empty-preview h3 {
    color: #333;
    margin-bottom: 0.5rem;
    font-size: 1.1rem;
  }
  
  .empty-preview p {
    margin: 0;
    font-size: 0.9rem;
    line-height: 1.4;
  }
</style>