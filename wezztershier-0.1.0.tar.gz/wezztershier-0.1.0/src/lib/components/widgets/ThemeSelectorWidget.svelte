<script>
  import { createEventDispatcher } from 'svelte';
  
  export let widget;
  export let widgetId;
  
  const dispatch = createEventDispatcher();
  
  $: themeData = widget.theme_selector;
  $: currentValue = widget.current_value;
  
  let selectedTheme = currentValue;
  let showPreview = false;
  
  // Sync selected value when widget data changes
  $: selectedTheme = currentValue;
  
  function handleChange(event) {
    const value = event.target.value;
    selectedTheme = value;
    dispatch('change', value);
  }
  
  function togglePreview() {
    showPreview = !showPreview;
  }
  
  function getCurrentTheme() {
    return themeData.available_themes.find(t => t.name === selectedTheme);
  }
  
  function getPreviewColors(theme) {
    if (!theme || !theme.colors) return [];
    
    const keys = ['background', 'foreground', 'red', 'green', 'blue', 'yellow', 'cyan', 'magenta'];
    return keys
      .filter(key => theme.colors[key])
      .map(key => ({
        name: key,
        color: theme.colors[key],
        label: key.charAt(0).toUpperCase() + key.slice(1)
      }));
  }
</script>

<div class="theme-selector-widget">
  <div class="theme-input-container">
    <select
      value={selectedTheme}
      on:change={handleChange}
      class="theme-select"
    >
      {#each themeData.available_themes as theme}
        <option value={theme.name}>
          {theme.display_name} {theme.is_dark ? '(Dark)' : '(Light)'}
        </option>
      {/each}
    </select>
    
    <button 
      type="button"
      on:click={togglePreview}
      class="preview-button"
      class:active={showPreview}
      title="Toggle theme preview"
    >
      🎨
    </button>
  </div>
  
  <div class="theme-info">
    {#if getCurrentTheme()}
      <div class="current-theme-info">
        <span class="theme-name">{getCurrentTheme().display_name}</span>
        <span class="theme-type" class:dark={getCurrentTheme().is_dark}>
          {getCurrentTheme().is_dark ? 'Dark' : 'Light'} Theme
        </span>
      </div>
      
      <div class="theme-description">
        {getCurrentTheme().description}
      </div>
      
      {#if getCurrentTheme().author}
        <div class="theme-author">
          by {getCurrentTheme().author}
        </div>
      {/if}
    {/if}
  </div>
  
  {#if showPreview && getCurrentTheme()}
    <div class="theme-preview">
      <div class="preview-header">
        <h4>Color Preview</h4>
      </div>
      
      <div class="color-palette">
        {#each getPreviewColors(getCurrentTheme()) as colorInfo}
          <div class="color-item">
            <div 
              class="color-swatch" 
              style="background-color: {colorInfo.color}"
              title="{colorInfo.label}: {colorInfo.color}"
            ></div>
            <div class="color-info">
              <span class="color-name">{colorInfo.label}</span>
              <span class="color-value">{colorInfo.color}</span>
            </div>
          </div>
        {/each}
      </div>
      
      <div class="preview-demo">
        <div 
          class="terminal-preview" 
          style="background-color: {getCurrentTheme().colors.background}; color: {getCurrentTheme().colors.foreground}"
        >
          <div class="terminal-line">
            <span class="prompt" style="color: {getCurrentTheme().colors.green}">❯</span>
            <span class="command" style="color: {getCurrentTheme().colors.blue}">wezterm</span>
            <span style="color: {getCurrentTheme().colors.yellow}">--version</span>
          </div>
          <div class="terminal-line">
            <span style="color: {getCurrentTheme().colors.cyan}">WezTerm 20240203-110809-5046fc22</span>
          </div>
          <div class="terminal-line">
            <span class="error" style="color: {getCurrentTheme().colors.red}">Error:</span>
            <span>Something went wrong</span>
          </div>
        </div>
      </div>
    </div>
  {/if}
</div>

<style>
  .theme-selector-widget {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }
  
  .theme-input-container {
    display: flex;
    gap: 0.5rem;
    align-items: center;
  }
  
  .theme-select {
    flex: 1;
    padding: 0.75rem 1rem;
    border: 2px solid #e0e0e0;
    border-radius: 6px;
    font-size: 0.95rem;
    background: white;
    color: #333;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  
  .theme-select:hover {
    border-color: #c0c0c0;
  }
  
  .theme-select:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  .preview-button {
    padding: 0.75rem;
    border: 2px solid #e0e0e0;
    border-radius: 6px;
    background: white;
    cursor: pointer;
    font-size: 1rem;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .preview-button:hover {
    border-color: #667eea;
    background: #f8f9ff;
  }
  
  .preview-button.active {
    background: #667eea;
    border-color: #667eea;
    transform: scale(0.95);
  }
  
  .theme-info {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
    font-size: 0.9rem;
  }
  
  .current-theme-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .theme-name {
    font-weight: 600;
    color: #333;
  }
  
  .theme-type {
    font-size: 0.8rem;
    padding: 0.125rem 0.5rem;
    border-radius: 12px;
    background: #e8f4f8;
    color: #2563eb;
  }
  
  .theme-type.dark {
    background: #1f2937;
    color: #f3f4f6;
  }
  
  .theme-description {
    color: #666;
    font-size: 0.85rem;
    line-height: 1.3;
  }
  
  .theme-author {
    color: #888;
    font-size: 0.8rem;
    font-style: italic;
  }
  
  .theme-preview {
    background: #f8f9fa;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    overflow: hidden;
    margin-top: 0.5rem;
  }
  
  .preview-header {
    background: #667eea;
    color: white;
    padding: 0.75rem 1rem;
  }
  
  .preview-header h4 {
    margin: 0;
    font-size: 0.9rem;
    font-weight: 600;
  }
  
  .color-palette {
    padding: 1rem;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 0.75rem;
  }
  
  .color-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
  
  .color-swatch {
    width: 24px;
    height: 24px;
    border-radius: 4px;
    border: 1px solid rgba(0, 0, 0, 0.1);
    flex-shrink: 0;
  }
  
  .color-info {
    display: flex;
    flex-direction: column;
    font-size: 0.8rem;
    min-width: 0;
  }
  
  .color-name {
    font-weight: 500;
    color: #333;
    text-transform: capitalize;
  }
  
  .color-value {
    color: #666;
    font-family: monospace;
    font-size: 0.75rem;
  }
  
  .preview-demo {
    padding: 1rem;
    background: #fafafa;
    border-top: 1px solid #e0e0e0;
  }
  
  .terminal-preview {
    border-radius: 6px;
    padding: 1rem;
    font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
    font-size: 0.85rem;
    line-height: 1.4;
    border: 1px solid rgba(255, 255, 255, 0.1);
  }
  
  .terminal-line {
    margin-bottom: 0.25rem;
  }
  
  .terminal-line:last-child {
    margin-bottom: 0;
  }
  
  .prompt {
    font-weight: bold;
    margin-right: 0.5rem;
  }
  
  .command {
    font-weight: 600;
    margin-right: 0.5rem;
  }
  
  .error {
    font-weight: 600;
    margin-right: 0.5rem;
  }
</style>